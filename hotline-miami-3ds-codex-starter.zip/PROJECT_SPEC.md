# Product specification v1.0 (2026-11-01)

## Binding decisions
- **Target:** New 3DS and New 2DS XL exclusively; native 3DS C/C++ engine, not emulation.
- **Content source:** user's legitimate original *GameMaker* Hotline Miami 1 Steam installation. Engine repository does not contain any commercial sprites, music, game rooms, maps, scripts, levels or bundled game executables.
- **Objective:** approximate the entire original game faithfully: AI, timings, weapons, collision, behavior, scoring, masks, rooms, progression, cutscenes and audio; not yet implemented. Do not claim exact parity without evidence and comparative tests.
- **Displays:** gameplay on upper 400x240 screen; lower 320x240 screen for an explored-area-only live map, weapon/ammo and combo status, and transparent touch-aim input. Enemies appear on the map only when appropriately observable; no wall-hack or unexplored-room reveals.
- **Presentation:** crisp pixel art, nearest-neighbor scaling by default, original camera behavior translated to a smaller viewport. Camera and scaling specifics to be calibrated against lawful reference footage/testing.
- **Aim mode A:** Circle Pad moves, relative drag from any bottom-screen touch origin sets direction. Lift preserves last direction.
- **Aim mode B:** Circle Pad moves; C-stick sets independent aim while active, then after a configurable inactivity delay (~150 ms initial hypothesis) Circle Pad movement may retake aim. No drift; retain last facing while idle.
- **Combat bindings:** initial R attack, A interact/open door, X swap input scheme, Y room reset, Start exit; eventual fully configurable mappings. Prototype controls are not final.
- **Future stereo:** optional subtle floor/character/effect depth using the upper screen's stereoscopic 3D, disabled by default; not an initial milestone.
- **Performance target:** stable 60 rendered FPS on New hardware, preserve faithful simulation timing independently of render rate. Instrument frame times on actual hardware; no guarantee yet.
- **Saves:** native 3DS saves only; permanently separate from PC saves. Implement safe versioned and atomic save handling later.
- **Delivery:** `.3dsx` primary, `.cia` later if toolchain and icon/title tooling are verified. Do not pretend `.cia` is supported by this initial ZIP.
- **Development method:** playable vertical slices, working-build checkpoints and explicit hardware verification.

## Engine boundaries
Keep platform-specific inputs/rendering/SD functions separate from game logic as the codebase grows. No proprietary resource conversion until legitimate formats are audited and tool licensing reviewed. Asset conversions happen locally, not in public CI.

## Prototype versus finished port
The enclosed geometric demo is **not** Hotline Miami gameplay. It establishes compile/run/input/dual-screen foundations and intentionally simplistic combat. There is no game data parser, music, original AI, actual pixel sprites, scoring, or saves.
