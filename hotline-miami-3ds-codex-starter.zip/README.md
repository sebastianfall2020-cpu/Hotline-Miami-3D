# Hotline Miami 3DS — independent homebrew engine prototype

**Status:** pre-alpha source starter; not yet compiled or tested on a 3DS. This is not a playable port of Hotline Miami. It contains only original code and geometric placeholder graphics, no game assets or extracted code.

## Quick start
1. Create an empty GitHub repository. Extract **the contents** of this ZIP to the repository root (so `Makefile` is at root); commit and push.
2. Under **Actions > 3DS prototype > Run workflow**, or after a push, check the compile job. If successful download `hm3ds-3dsx` from that run's artifacts.
3. Copy `hotline-miami-3ds.3dsx` to `/3ds/hotline-miami-3ds/hotline-miami-3ds.3dsx` on the SD card, launch via Homebrew Launcher.
4. Test on a New Nintendo 3DS or New Nintendo 2DS XL. Report the exact commit, steps, and observations in a GitHub issue.

No `.3dsx` is bundled: this environment has no devkitARM installation and compilation must be confirmed through CI or a local devkitPro environment.

## Controls (prototype)
- Circle Pad: move; in adaptive mode also aims after C-stick idle timeout.
- C-stick: independently aim (New hardware only).
- X: toggle touch/adaptive modes.
- Touch: drag relative to first contact to aim in touch mode.
- R: attack nearby enemy in aimed direction (simplified prototype).
- A: open/close door when nearby.
- Y: restart placeholder room.
- START: exit.

The bottom screen shows a simple explored map with player/enemy markers and prototype combat information. No actual Hotline Miami resources are required.

## Build
Install devkitPro's 3DS development packages (`3ds-dev` group), including devkitARM, libctru, citro3d and citro2d, then run `make`. The project follows devkitPro's 3DS application-template Makefile conventions. GitHub Actions uses the devkitPro devkitARM container.

## Next tasks
See [MILESTONES.md](MILESTONES.md), [PROJECT_SPEC.md](PROJECT_SPEC.md), [AGENTS.md](AGENTS.md). Inspect the *user's original GameMaker Steam installation locally* before choosing a converter; do not commit Steam content.
