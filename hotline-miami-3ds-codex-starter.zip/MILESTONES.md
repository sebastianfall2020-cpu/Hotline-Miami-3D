# Milestones and verification

## M0 — Hardware foundation (included as **unverified source**)
- [ ] GitHub Actions compiles a valid `.3dsx` artifact.
- [ ] Device boots and exits safely (START).
- [ ] Geometry renders on top screen, explored minimap and text on bottom.
- [ ] Circle Pad movement and wall blocking work.
- [ ] C-stick controls independent aim; on timeout Circle Pad fallback works.
- [ ] Drag-to-aim on bottom screen works in touch mode; release preserves direction.
- [ ] A toggles door, R eliminates a nearby enemy, Y resets room.
- [ ] Hardware FPS/frame pacing recorded. No crashes during 10-minute test.

## M1 — Original playable test room (not done)
- [ ] Replace geometric placeholders with original independently drawn pixel artwork.
- [ ] Implement proper hitboxes, attacks, enemy state machine, kill/death/respawn, basic weapon types.
- [ ] Separate game simulation, input bindings and rendering into modules.
- [ ] Unit tests for aim-mode arbitration, collisions, deterministic combat.

## M2 — User-owned asset conversion (not done)
- [ ] Analyze actual original GameMaker installation structure locally; document relevant format/version.
- [ ] Select lawful, versioned conversion approach compatible with dependency licenses.
- [ ] Convert owned assets locally only; demonstrate a single converted sprite/audio resource on device.

## M3 — Game compatibility (not done)
- [ ] Recreate key game systems and representative original rooms; verify behavior on original PC release.
- [ ] Implement scoring, masks, level sequence, checkpoints, menus, music and progression.

## M4 — Performance and packaging (not done)
- [ ] Stable frame time on New hardware in representative heavy rooms; profiling data included.
- [ ] Persistent 3DS-only saves with recovery, optional .cia install packaging.
- [ ] Stereo layer option tested without gameplay regression.
