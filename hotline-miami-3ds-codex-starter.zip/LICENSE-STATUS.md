# License status

This starter contains independently authored example code and documentation, but no license for future community contributions has been selected. Before making the repository public or accepting contributions, choose a suitable open-source license and ensure any dependencies, code copied from devkitPro examples, or external extractors have compatible terms. The official game's names and assets belong to their respective owners; this project is unaffiliated.
