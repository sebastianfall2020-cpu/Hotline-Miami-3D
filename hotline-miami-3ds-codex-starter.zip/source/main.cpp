#include <3ds.h>
#include <citro2d.h>
#include <cmath>
#include <cstdio>

// Original geometry-only proof of concept, not copied game content.
namespace {
constexpr float W = 400.0f, H = 240.0f;
constexpr float SPEED = 1.9f;
constexpr float PI = 3.14159265f;
constexpr int ENEMY_COUNT = 3;
struct Actor { float x, y; bool alive; };
Actor player{75, 120, true};
Actor enemies[ENEMY_COUNT] = {{285,70,true},{320,150,true},{235,175,true}};
float aimx = 1, aimy = 0;
float touchStartX = 0, touchStartY = 0;
float lastStickTime = -1000.0f;
float elapsed = 0;
bool touchMode = false, doorOpen = false, touchWasDown = false;
int combo = 0, ammo = 0;

u32 color(int r,int g,int b) { return C2D_Color32(r,g,b,255); }
void rect(float x,float y,float w,float h,u32 c) { C2D_DrawRectSolid(x,y,0,w,h,c); }
void reset() {
 player={75,120,true}; enemies[0]={285,70,true}; enemies[1]={320,150,true}; enemies[2]={235,175,true};
 aimx=1; aimy=0; doorOpen=false; combo=0; ammo=0;
}
bool solid(float x,float y) {
 if(x<20 || x>380 || y<20 || y>220) return true;
 // Interior partition, with a door between y=100 and y=140.
 if(x>195 && x<207 && (y<100 || y>140 || !doorOpen)) return true;
 return false;
}
void norm(float x,float y,float& ox,float& oy) {
 float length=std::sqrt(x*x+y*y);
 if(length>0.001f) { ox=x/length; oy=y/length; }
}
void drawText(C2D_TextBuf buf,C2D_Font font,float x,float y,float scale,u32 c,const char* s) {
 C2D_Text text; C2D_TextFontParse(&text,font,buf,s); C2D_TextOptimize(&text);
 C2D_DrawText(&text,C2D_WithColor,x,y,0,scale,scale,c);
}
}
int main(int, char**) {
 gfxInitDefault();
 if (!C3D_Init(C3D_DEFAULT_CMDBUF_SIZE)) { gfxExit(); return 1; }
 if (!C2D_Init(C2D_DEFAULT_MAX_OBJECTS)) { C3D_Fini(); gfxExit(); return 2; }
 C2D_Prepare();
 C3D_RenderTarget* top=C2D_CreateScreenTarget(GFX_TOP,GFX_LEFT);
 C3D_RenderTarget* bottom=C2D_CreateScreenTarget(GFX_BOTTOM,GFX_LEFT);
 C2D_TextBuf textbuf=C2D_TextBufNew(4096);
 C2D_Font font=C2D_FontLoadSystem(CFG_REGION_USA);
 const bool cstickAvailable=R_SUCCEEDED(irrstInit());
 const u32 wall=color(77,70,88), floor=color(34,28,48), playerColor=color(82,214,217), enemyColor=color(255,88,117);
 while(aptMainLoop()) {
  hidScanInput(); const u32 down=hidKeysDown(), held=hidKeysHeld();
  if(down & KEY_START) break;
  if(down & KEY_X) { touchMode=!touchMode; touchWasDown=false; }
  if(down & KEY_Y) reset();
  circlePosition cp{0,0}; hidCircleRead(&cp);
  float mx=cp.dx/156.f, my=-cp.dy/156.f;
  float mag=std::sqrt(mx*mx+my*my);
  if(mag>1) { mx/=mag; my/=mag; }
  if(mag<0.12f) { mx=0; my=0; }
  if (!touchMode) {
   // C-stick values are available on New-family hardware through IRRST.
   circlePosition cs{0,0};
   if (cstickAvailable) irrstCstickRead(&cs);
   float cx=cs.dx, cy=-cs.dy;
   if(cx*cx+cy*cy>400.0f) { norm(cx,cy,aimx,aimy); lastStickTime=elapsed; }
   else if(elapsed-lastStickTime>0.15f && (mx*mx+my*my)>0.02f) norm(mx,my,aimx,aimy);
  } else {
   bool touching=(held & KEY_TOUCH)!=0;
   if(touching) {
    touchPosition tp; hidTouchRead(&tp);
    if(!touchWasDown) { touchStartX=tp.px; touchStartY=tp.py; }
    else { float dx=tp.px-touchStartX,dy=tp.py-touchStartY; if(dx*dx+dy*dy>64.f) norm(dx,dy,aimx,aimy); }
   }
   touchWasDown=touching;
  }
  float nx=player.x+mx*SPEED, ny=player.y+my*SPEED;
  if(!solid(nx,player.y)) player.x=nx;
  if(!solid(player.x,ny)) player.y=ny;
  if((down & KEY_A) && std::fabs(player.x-200)<30 && player.y>85 && player.y<155) doorOpen=!doorOpen;
  if(down & KEY_R) {
   for(auto& e:enemies) {
    if(!e.alive) continue;
    float dx=e.x-player.x,dy=e.y-player.y,dist=std::sqrt(dx*dx+dy*dy);
    if(dist<55 && dist>0 && (dx*aimx+dy*aimy)/dist>0.70f && !(player.x<195 && e.x>207 && !doorOpen)) { e.alive=false; ++combo; break; }
   }
  }
  C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
  C2D_TargetClear(top,color(13,10,22)); C2D_SceneBegin(top);
  rect(20,20,360,200,floor);
  rect(12,12,376,8,wall); rect(12,220,376,8,wall); rect(12,12,8,216,wall); rect(380,12,8,216,wall);
  rect(195,20,12,80,wall); rect(195,140,12,80,wall);
  if(!doorOpen) rect(195,100,12,40,color(181,129,73));
  for(const auto& e:enemies) if(e.alive) rect(e.x-6,e.y-6,12,12,enemyColor);
  rect(player.x-6,player.y-6,12,12,playerColor);
  rect(player.x+aimx*10-2,player.y+aimy*10-2,4,4,color(255,244,166));
  C2D_TargetClear(bottom,color(9,14,24)); C2D_SceneBegin(bottom);
  rect(16,15,288,162,color(24,32,46));
  // Simplified explored map: intentionally shows only geometry, no enemies through walls.
  rect(32,31,256,128,color(48,51,67));
  rect(159,31,4,49,color(100,104,120)); rect(159,110,4,49,color(100,104,120));
  if(!doorOpen) rect(159,80,4,30,color(187,127,72));
  rect(32+(player.x-20)*256/360-3,31+(player.y-20)*128/200-3,6,6,playerColor);
  char info[160];
  std::snprintf(info,sizeof(info),"%s | R attack | A door | X swap",touchMode?"TOUCH":"C-STICK");
  C2D_TextBufClear(textbuf);
  if(font) drawText(textbuf,font,16,182,0.42f,color(235,225,235),info);
  std::snprintf(info,sizeof(info),"Combo: %d     Ammo: %d     Y reset     START exit",combo,ammo);
  if(font) drawText(textbuf,font,16,207,0.42f,color(235,225,235),info);
  C3D_FrameEnd(0);
  elapsed+=1.0f/60.0f; // Prototype-only clock assumption. Replace with actual elapsed ticks/fixed-step timing.
 }
 if(cstickAvailable) irrstExit();
 if(font) C2D_FontFree(font);
 C2D_TextBufDelete(textbuf); C2D_Fini(); C3D_Fini(); gfxExit(); return 0;
}
