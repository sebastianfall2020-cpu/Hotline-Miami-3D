# Codex development rules

Read `PROJECT_SPEC.md`, `MILESTONES.md`, `TESTING.md` before making changes.

1. Preserve the chosen scope; do not quietly change New-3DS-only target, GameMaker asset origin, save separation, screen arrangement, or two aiming schemes.
2. Avoid copyrighted/proprietary Hotline Miami game files, decompiled game code, soundtrack, art, map data, or game binaries in repository, examples, CI artifacts, or logs. All placeholder designs must be original. Do not download ROMs or Steam game files in CI.
3. Prefer small, reviewable edits. Never say a binary compiled unless an actual compiler succeeded, and never say tested on hardware without a report.
4. Run local host tests where available, and `make` in devkitPro environment. Capture compiler output if failed; fix or record failures honestly.
5. Never regress existing working input modes or top/bottom rendering. If functionality changes, update spec, tests, controls and milestone notes.
6. No unreviewed large refactors; keep simulation/rendering separate, use fixed timestep in future. Keep C++17 compatibility with devkitARM.
7. Treat each milestone as incomplete until acceptance criteria demonstrated, with hardware test requiring human operator.
8. Keep Git commits and pull requests bounded; main should represent reviewed builds. No destructive repository operations without approval.
9. Use feature branches, GitHub Actions artifacts and short reproducible testing steps. Favor independent platform-side logic to enable host tests.
10. When modifying gameplay, distinguish original-game observed behavior, inference, and intentional placeholder approximation.

## First Codex task
Run CI; resolve any errors against current devkitPro API; produce a `.3dsx` workflow artifact; request a hardware smoke test. Do not move forward to resource extraction until build and basic controls are verified.
