# Hardware test report template

**Git commit / workflow run:**
**Console:** New 3DS / New 2DS XL (firmware, CFW, Homebrew Launcher version if relevant)
**Build filename:**
**Test duration:**

- [ ] Boot / exit
- [ ] Circle Pad movement / wall collisions
- [ ] C-stick aim / timeout fallback
- [ ] X changes scheme
- [ ] Touch direction drag / release
- [ ] A door toggle / R attack / Y reset
- [ ] Map explored visibility
- [ ] Top and bottom renders correctly
- [ ] No crashes or hangs

**Actual FPS / frame times:**
**Reproduction steps for any bug:**
**Expected vs observed:**
**Photograph/video or error dump location (do not include proprietary game assets):**

CI compile success does not constitute device execution or performance certification.
