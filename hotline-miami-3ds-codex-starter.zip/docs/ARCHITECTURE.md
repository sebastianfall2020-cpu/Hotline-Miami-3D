# Architecture notes

The initial sample intentionally has one main translation unit to minimize compile dependencies. After first verified hardware run, refactor into `platform/` input+renderer, `game/` deterministic simulation, `ui/` bottom map and HUD, `assets/` parser/loader. A 60 Hz render loop is not a reliable clock: replace the current nominal elapsed counter with monotonic system timing and an accumulator before serious physics or AI. Cache fonts and static text; consider a GPU sprite atlas once using pixel art. No extracted content goes into CI.
